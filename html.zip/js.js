document.addEventListener("DOMContentLoaded", function(){
  //menu do kupowania nieruchomości
var displayMenu = function (){

  // console.log(this.getAttribute("resource1"));
  // console.log(this.getAttribute("resource2"));
  // console.log(this.getAttribute("resource3"));
  // console.log(this.getAttribute("number1"));
  // console.log(this.getAttribute("number2"));
  // console.log(this.getAttribute("number3"));
  // console.log(this.getAttribute("water"));
  // console.log(this.getAttribute("row"));
  // console.log(this.getAttribute("no"));
  // console.log(this.getAttribute("index"));
  // console.log(this.getAttribute("possessor"));
  // console.log(this.getAttribute("realEstate"));
  //   console.log(this.getAttribute("gameNumber"));
  console.log(this.className)


  var newMenu = document.getElementById(this.id + " menu");
  if (this.getAttribute("number1") != null || this.getAttribute("number2") != null || this.getAttribute("number3") != null ){
    newMenu.style.display = "inline-block";


    newMenu.appendChild(li1);
    newMenu.appendChild(li2);
    newMenu.appendChild(li3);
    newMenu.appendChild(li4);
    newMenu.appendChild(li5);
    newMenu.appendChild(li6);
    newMenu.appendChild(li7);

  var lis = document.querySelectorAll("li")
  for (var i = 0; i < lis.length; i++){
    lis[i].addEventListener("mouseover", function() {
    this.style.backgroundColor = "black";
    })
    lis[i].addEventListener("mouseout", function() {
    this.style.backgroundColor = "rgba(0, 0, 0, 0.5)";
    })
    }
  }
  };


var x = 0;
var y = 0;
var t = 0;
var h = 0;
var height = 22;
var width = 12;
var id = 0;
var gameStart = false;
var totalNumber = 0;

var body = document.querySelector("body")
var fields = [ "desert.jpg", "bricks.jpg", "wood.jpg", "iron.jpg", "food.jpg", "stones.jpg", "wheat.jpg", "bricks.jpg", "wood.jpg", "iron.jpg", "food.jpg", "stones.jpg", "wheat.jpg", "bricks.jpg", "wood.jpg", "iron.jpg", "food.jpg", "stones.jpg", "wheat.jpg"];
var sea = ["sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg", "sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","bricks.jpg", "gold.jpg", "gold.jpg", "wood.jpg", "iron.jpg", "food.jpg", "stones.jpg", "wheat.jpg"];
var cost = ["sea.jpg", "sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg" ,"sea.jpg","sea.jpg" ,"sea.jpg","sea.jpg","sea.jpg", "sea.jpg","sea.jpg","sea.jpg", "sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg", "sea.jpg","sea.jpg","sea.jpg","sea.jpg","sea.jpg", "bricks.jpg", "wood.jpg", "iron.jpg", "food.jpg", "stones.jpg", "wheat.jpg"];
var value = [2, 3, 4, 5, 6, 8, 9, 10, 11, 12];


for (var i = 0; i < height; i++){
  for (var j = 0; j < width; j++) {

    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");
    if ((j === 0 && i%2 === 0) || i === 0 || i === 1 || i === 21 || i === 20 || (j === 11 && i%2 != 0)) {

      var field = "sea.jpg";

      var painting = function (x, y, field){

        var img =new Image();
            img.src = field;
            img.onload = function() {

                  var pattern=ctx.createPattern(img,'repeat');
                  ctx.strokeStyle = "black";
                  ctx.fillStyle = pattern;
                  ctx.lineWidth = 2;
                  ctx.beginPath();
                  ctx.moveTo(60 + x, 50 + y);
                  ctx.lineTo(101 + x, 50 + y);
                  ctx.lineTo(122 + x, 86 + y);
                  ctx.lineTo(101 + x, 121 + y);
                  ctx.lineTo(60 + x, 121 + y);
                  ctx.lineTo(40 + x, 85 + y);
                  ctx.lineTo(60 + x, 50 + y);
                  ctx.fill();
                  ctx.stroke();
                };
      }

      painting(x, y, field);

    } else if (j < 4){

var field = fields[Math.floor(Math.random() * fields.length)];

      var painting2 = function (x, y, field){
            var img =new Image();
          img.src = field;
            img.onload = function() {

                  var pattern=ctx.createPattern(img,'repeat');
                  ctx.strokeStyle = "black";
                  ctx.fillStyle = pattern;
                  ctx.lineWidth = 2;
                  ctx.beginPath();
                  ctx.moveTo(60 + x, 50 + y);
                  ctx.lineTo(101 + x, 50 + y);
                  ctx.lineTo(122 + x, 86 + y);
                  ctx.lineTo(101 + x, 121 + y);
                  ctx.lineTo(60 + x, 121 + y);
                  ctx.lineTo(40 + x, 85 + y);
                  ctx.lineTo(60 + x, 50 + y);
                  ctx.fill();
                  ctx.stroke();
                };
      }

      painting2(x, y, field);


    } else if ( j === 4){

var field = cost[Math.floor(Math.random() * cost.length)];

      var painting3 = function (x, y, field){
            var img =new Image();
          img.src = field;
            img.onload = function() {

                  var pattern=ctx.createPattern(img,'repeat');
                  ctx.strokeStyle = "black";
                  ctx.fillStyle = pattern;
                  ctx.lineWidth = 2;
                  ctx.beginPath();
                  ctx.moveTo(60 + x, 50 + y);
                  ctx.lineTo(101 + x, 50 + y);
                  ctx.lineTo(122 + x, 86 + y);
                  ctx.lineTo(101 + x, 121 + y);
                  ctx.lineTo(60 + x, 121 + y);
                  ctx.lineTo(40 + x, 85 + y);
                  ctx.lineTo(60 + x, 50 + y);
                  ctx.fill();
                  ctx.stroke();
                };
      }

      painting3(x, y, field);


    } else {

      var field = sea[Math.floor(Math.random() * sea.length)];

      var painting4 = function (x, y, field){
            var img =new Image();

          img.src = field;
            img.onload = function() {

                  var pattern=ctx.createPattern(img,'repeat');
                  ctx.strokeStyle = "black";
                  ctx.fillStyle = pattern;
                  ctx.lineWidth = 2;
                  ctx.beginPath();
                  ctx.moveTo(60 + x, 50 + y);
                  ctx.lineTo(101 + x, 50 + y);
                  ctx.lineTo(122 + x, 86 + y);
                  ctx.lineTo(101 + x, 121 + y);
                  ctx.lineTo(60 + x, 121 + y);
                  ctx.lineTo(40 + x, 85 + y);
                  ctx.lineTo(60 + x, 50 + y);
                  ctx.fill();
                  ctx.stroke();
                };
      }

      painting3(x, y, field);
  }


if (field != "sea.jpg"){
    var newDiv = document.createElement("div");
    body.appendChild(newDiv);
    newDiv.classList.add("numbers");
    if (field != "desert.jpg") {
    newDiv.style.width = "20px";
    newDiv.style.height = "20px"
    newDiv.style.borderRadius = "50%";
    newDiv.style.top = 82 + y + "px";
    newDiv.style.left = 77 + x + "px";
    newDiv.style.border = "1px solid black";
    newDiv.innerText = value[Math.floor(Math.random() * value.length)];
    newDiv.setAttribute("number", newDiv.innerText);
    newDiv.style.textAlign = "center";
    newDiv.style.backgroundColor = "white";
    if (newDiv.innerText === "6" || newDiv.innerText === "8"){
      newDiv.style.color = "red";
      newDiv.style.fontWeight = "bold";
    }
}
    var fieldString = field.replace(".jpg", "");
    newDiv.setAttribute('resource', fieldString);
    newDiv.id = "number = row " + i + " no " + j;
    newDiv.style.display = "inline-block"
    newDiv.setAttribute("row", i);
    newDiv.setAttribute("no", j);
    newDiv.style.position = "absolute";

}
for (var z = 0; z < 2; z++){

  if (z%2 == 0){

  var newDivRoad = document.createElement("div");
  newDivRoad.style.width = "5px";
  newDivRoad.style.height = "5px";
  newDivRoad.style.display = "inline-block";
  newDivRoad.style.position = "absolute";
  newDivRoad.style.top = 53 + y + "px";
  newDivRoad.style.left = 85 + x + "px";
  newDivRoad.id = "road = row " + i + " no " + j + " middle";
  newDivRoad.setAttribute("row", i);
  newDivRoad.setAttribute("number", j);

  var menuRoad = document.createElement("ul");
    menuRoad.style.position = "absolute";
    menuRoad.style.padding = "0";
    menuRoad.style.display = "none";
    menuRoad.style.zIndex = "1";

    newDivRoad.appendChild(menuRoad);

    var li1Road = document.createElement("li");
    li1Road.innerText = "road";
    var li2Road = document.createElement("li");
    li2Road.innerText = "none";


//budowa drogi nr1
li1Road.addEventListener("click", function(){
  event.stopPropagation();
  var road = document.createElement("div");
  road.style.width = "20px";
  road.style.height = "5px";
  road.style.display = "inline-block";
  road.style.position = "absolute";
  road.style.left = "-5px";
  if (playerTurns === 2){
    road.style.backgroundColor = "blue";
    this.parentElement.parentElement.setAttribute("possessor", 0);
  } else if (playerTurns === 3){
    road.style.backgroundColor = "white";
    this.parentElement.parentElement.setAttribute("possessor", 1);
  } else if (playerTurns === 4){
    road.style.backgroundColor = "yellow";
    this.parentElement.parentElement.setAttribute("possessor", 2);
  } else if (playerTurns === 1){
    road.style.backgroundColor = "green";
    this.parentElement.parentElement.setAttribute("possessor", 3);
  };

this.parentElement.parentElement.appendChild(road);
console.log(road);

    this.parentElement.style.display = "none";

});

li2Road.addEventListener("click", function(){
  event.stopPropagation();
    this.parentElement.style.display = "none";

});



  menuRoad.appendChild(li1Road);
  menuRoad.appendChild(li2Road);

  newDivRoad.addEventListener('click', function(){
  console.log(this.id);
  if (document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index0').getAttribute('possessor') - playerTurns == 2 ||
  document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index0').getAttribute('possessor') - playerTurns == - 2 ||
  document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index1').getAttribute('possessor') - playerTurns == -2 ||
  document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index1').getAttribute('possessor') - playerTurns == 2 ||
  (document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null) ||
  (document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') - playerTurns == -2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null) ||
  (document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') != null) ||
  (document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == -2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') != null))

  {
    this.firstElementChild.style.display = "inline-block";
  } else if (
    this.getAttribute("row") != 0 &&
    ((document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null) ||
    (document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') - playerTurns == -2 && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null) ||

    (document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number")*1 +1) + ' left').getAttribute('possessor') - playerTurns == 2
    && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number")*1 +1) + ' left').getAttribute('possessor') != null) ||
    (document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number")*1 +1) + ' left').getAttribute('possessor') - playerTurns == -2
    && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number")*1 +1) + ' left').getAttribute('possessor') != null) ||

    (document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == 2
    && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') != null) ||
    (document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == -2
    && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') != null))
  ) {
    this.firstElementChild.style.display = "inline-block";
  } else if ((this.getAttribute("row") != 0 && (this.getAttribute("number") != 0) &&
  (  (document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number") -1) + ' right').getAttribute('possessor') - playerTurns == 2
  && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number") -1) + ' right').getAttribute('possessor') != null) ||
    (document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number") -1) + ' right').getAttribute('possessor') - playerTurns == -2
    && document.getElementById('road = row ' + (this.getAttribute("row")-1) + ' no ' + (this.getAttribute("number") -1) + ' right').getAttribute('possessor') != null))))
   {
    this.firstElementChild.style.display = "inline-block";
  }



  })
  body.appendChild(newDivRoad);
} else {
  var newDivRoad = document.createElement("div");
  newDivRoad.style.width = "5px";
  newDivRoad.style.height = "5px";
  newDivRoad.style.display = "inline-block";
  newDivRoad.style.position = "absolute";
  newDivRoad.style.top = 71 + y + "px";
  newDivRoad.style.left = 54 + x + "px";
  newDivRoad.id = "road = row " + i + " no " + j + " left";
  newDivRoad.setAttribute("row", i);
  newDivRoad.setAttribute("number", j);

  var menuRoad = document.createElement("ul");
    menuRoad.style.position = "absolute";
    menuRoad.style.padding = "0";
    menuRoad.style.display = "none";
    menuRoad.style.zIndex = "1";

    newDivRoad.appendChild(menuRoad);

    var li1Road = document.createElement("li");
    li1Road.innerText = "road";
    var li2Road = document.createElement("li");
    li2Road.innerText = "none";

//budowa drogi nr 2
li1Road.addEventListener("click", function(){
  event.stopPropagation();
  var road = document.createElement("div");
  road.style.width = "20px";
  road.style.height = "5px";
  road.style.display = "inline-block";
  road.style.position = "absolute";
  road.style.left = "-5px";
  road.style.transform = "rotate(-55deg)";
  if (playerTurns === 2){
    road.style.backgroundColor = "blue";
    this.parentElement.parentElement.setAttribute("possessor", 0);
  } else if (playerTurns === 3){
    road.style.backgroundColor = "white";
    this.parentElement.parentElement.setAttribute("possessor", 1);
  } else if (playerTurns === 4){
    road.style.backgroundColor = "yellow";
    this.parentElement.parentElement.setAttribute("possessor", 2);
  } else if (playerTurns === 1){
    road.style.backgroundColor = "green";
    this.parentElement.parentElement.setAttribute("possessor", 3);
  };

this.parentElement.parentElement.appendChild(road);
console.log(road);

    this.parentElement.style.display = "none";

});

li2Road.addEventListener("click", function(){
  event.stopPropagation();
    this.parentElement.style.display = "none";

});



  menuRoad.appendChild(li1Road);
  menuRoad.appendChild(li2Road);


  newDivRoad.setAttribute("i", i);
  newDivRoad.addEventListener('click', function(){
      
      console.log(this.id)
      
    if (this.getAttribute("i")%2 == 0){
      var minus = -1;
    } else {
      var minus = 0;
    }

    // do poprawy - warunki budowania lewej drogi
    if ((this.getAttribute("row") % 2 != 0 && (document.querySelector('.row'+(this.getAttribute("row")*1 + 1) +'no'+(this.getAttribute("number")*1 + minus) +'index1').getAttribute('possessor') - playerTurns == 2 ||
    document.querySelector('.row'+(this.getAttribute("row")*1 + 1) +'no'+(this.getAttribute("number")*1 + minus) +'index1').getAttribute('possessor') - playerTurns == -2 ||
    document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index0').getAttribute('possessor') - playerTurns == -2 ||
    document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index0').getAttribute('possessor') - playerTurns == 2) ||
    document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||
             
    document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') - playerTurns == - 2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||     
         
         
         
    document.getElementById('road = row ' + (this.getAttribute("row")*1 +1) + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||
         
    document.getElementById('road = row ' + (this.getAttribute("row")*1 +1) + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') - playerTurns == -2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||     
         
         
    document.getElementById('road = row ' + (this.getAttribute("row")*1 +1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null ||

    document.getElementById('road = row ' + (this.getAttribute("row")*1 +1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') - playerTurns == -2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null))    
        
        
    {
    this.firstElementChild.style.display = "inline-block";
    }

  })
  body.appendChild(newDivRoad);
  var newDivRoad = document.createElement("div");
  newDivRoad.style.width = "5px";
  newDivRoad.style.height = "5px";
  newDivRoad.style.display = "inline-block";
  newDivRoad.style.position = "absolute";
  newDivRoad.style.top = 71 + y + "px";
  newDivRoad.style.left = 116 + x + "px";
  // newDivRoad.style.border = "1px solid white";
  newDivRoad.id = "road = row " + i + " no " + j + " right";
  newDivRoad.setAttribute("row", i);
  newDivRoad.setAttribute("number", j);


  var menuRoad = document.createElement("ul");
    menuRoad.style.position = "absolute";
    menuRoad.style.padding = "0";
    menuRoad.style.display = "none";
    menuRoad.style.zIndex = "1";

    newDivRoad.appendChild(menuRoad);

    var li1Road = document.createElement("li");
    li1Road.innerText = "road";
    var li2Road = document.createElement("li");
    li2Road.innerText = "none";


//budowa drogi nr3
li1Road.addEventListener("click", function(){
  event.stopPropagation();
  var road = document.createElement("div");
  road.style.width = "20px";
  road.style.height = "5px";
  road.style.display = "inline-block";
  road.style.position = "absolute";
  road.style.left = "-5px";
  road.style.transform = "rotate(55deg)";
  if (playerTurns === 2){
    road.style.backgroundColor = "blue";
    this.parentElement.parentElement.setAttribute("possessor", 0);
  } else if (playerTurns === 3){
    road.style.backgroundColor = "white";
    this.parentElement.parentElement.setAttribute("possessor", 1);
  } else if (playerTurns === 4){
    road.style.backgroundColor = "yellow";
    this.parentElement.parentElement.setAttribute("possessor", 2);
  } else if (playerTurns === 1){
    road.style.backgroundColor = "green";
    this.parentElement.parentElement.setAttribute("possessor", 3);
  };

this.parentElement.parentElement.appendChild(road);
console.log(road);

    this.parentElement.style.display = "none";

});

li2Road.addEventListener("click", function(){
  event.stopPropagation();
    this.parentElement.style.display = "none";

});



  menuRoad.appendChild(li1Road);
  menuRoad.appendChild(li2Road);


    newDivRoad.setAttribute("i", i);
  newDivRoad.addEventListener('click', function(){
console.log(this.id);
        if (this.getAttribute("i")%2 != 0){
          var minus = 1;
        } else {
          var minus = 0;
        }

        if (document.querySelector('.row'+(this.getAttribute("row")*1 + 1) +'no'+(this.getAttribute("number")*1 + minus) +'index0').getAttribute('possessor') - playerTurns == 2 ||
        document.querySelector('.row'+(this.getAttribute("row")*1 + 1) +'no'+(this.getAttribute("number")*1 + minus) +'index0').getAttribute('possessor') - playerTurns == -2 ||
        document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index1').getAttribute('possessor') - playerTurns == -2 ||
        document.querySelector('.row'+this.getAttribute("row")+'no'+this.getAttribute("number")+'index1').getAttribute('possessor') - playerTurns == 2 ||
            
    document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||
             
    document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') - playerTurns == - 2 && document.getElementById('road = row ' + this.getAttribute("row") + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||     
         
         
         
    document.getElementById('road = row ' + (this.getAttribute("row")*1 - 1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||
         
    document.getElementById('road = row ' + (this.getAttribute("row")*1 -1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == -2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' middle').getAttribute('possessor') != null ||     
         
         
    document.getElementById('road = row ' + (this.getAttribute("row")*1 +1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == 2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null ||

    document.getElementById('road = row ' + (this.getAttribute("row")*1 +1) + ' no ' + this.getAttribute("number") + ' left').getAttribute('possessor') - playerTurns == -2 && document.getElementById('road = row ' + (this.getAttribute("row")*1+1) + ' no ' + this.getAttribute("number") + ' right').getAttribute('possessor') != null)  
        
    
            
            {
        this.firstElementChild.style.display = "inline-block";
        }
  })
  body.appendChild(newDivRoad);
}



var newDivField = document.createElement("div");
body.appendChild(newDivField);
newDivField.id = id;
newDivField.setAttribute("row", i)
newDivField.setAttribute("no", j)
newDivField.setAttribute("index", z);
newDivField.setAttribute("realEstate", "none");
newDivField.setAttribute("possessor", "none");
newDivField.classList.add("row"+i+"no"+j+"index"+z);
newDivField.classList.add("connections");
newDivField.style.width = "10px";
newDivField.style.height = "10px";
newDivField.style.position = "absolute";
newDivField.style.top = 50 + t + "px";
newDivField.style.left = 60 + h + "px";
// newDivField.style.border = "2px dashed black";
newDivField.style.borderRadius = "50px";

var menu = document.createElement("ul");
  menu.style.position = "absolute";
  menu.style.padding = "0";
  menu.style.display = "none";
  menu.style.zIndex = "1";
  menu.id = id + " menu";

  newDivField.appendChild(menu);

  var li1 = document.createElement("li");
  li1.innerText = "village";
  var li2 = document.createElement("li");
  li2.innerText = "town";
  var li3 = document.createElement("li");
  li3.innerText = "capital";
  var li4 = document.createElement("li");
  li4.innerText = "port village"
  var li5 = document.createElement("li");
  li5.innerText = "castle";
  var li6 = document.createElement("li");
  li6.innerText = "walls";
  var li7 = document.createElement("li");
  li7.innerText = "none";

// budowa do uzupełnienia

  li1.addEventListener("click", function(){
console.log(gameStart)
if (this.parentElement.parentElement.getAttribute("realEstate") === "none" && gameStart === true){

this.parentElement.parentElement.setAttribute("realEstate", "village");

var ind1 = this.parentElement.parentElement.getAttribute("index");
    if (ind1 === "0"){
      ind1++;
      }
      else if (ind1 === "1"){
        ind1--;
      }

var no1 = this.parentElement.parentElement.getAttribute("no");
var row1 = this.parentElement.parentElement.getAttribute("row");

var neibourgh1 = document.querySelector(".row"+row1+"no"+no1+"index"+ind1);
neibourgh1.removeEventListener("click", displayMenu);

var no2 = this.parentElement.parentElement.getAttribute("no");
var ind2 = this.parentElement.parentElement.getAttribute("index");
var row2 = this.parentElement.parentElement.getAttribute("row")-1;


    if (ind2 == 0 && row2%2 == 0){
      ind2++;
    } else if (ind2 == 0 && row2%2 != 0){
      ind2++;
      no2--;
    }
      else if (ind2 == 1 && row2%2 == 0){
        ind2--;
        no2++;
      } else if (ind2 == 1 && row2%2 != 0){
        ind2--;
      }



var neibourgh2 = document.querySelector(".row"+row2+"no"+no2+"index"+ind2);
neibourgh2.removeEventListener("click", displayMenu);

var no3 = this.parentElement.parentElement.getAttribute("no");
var ind3 = this.parentElement.parentElement.getAttribute("index");
var row3 = this.parentElement.parentElement.getAttribute("row")*1+1;

if (ind3 == 0 && row3%2 == 0){
  ind3++;
} else if (ind3 == 0 && row3%2 != 0){
  ind3++;
  no3--;
}
  else if (ind3 == 1 && row3%2 == 0){
    ind3--;
    no3++;
  } else if (ind3 == 1 && row3%2 != 0){
    ind3--;
  }

var neibourgh3 = document.querySelector(".row"+row3+"no"+no3+"index"+ind3);
console.log(row3)
if(row3 != height){
neibourgh3.removeEventListener("click", displayMenu);
}

      event.stopPropagation();
    var icon = document.createElement("i");
    if (playerSettling === 1 || playerSettling === 8 || playerTurns === 2){
      icon.style.color = "blue";
      this.parentElement.parentElement.setAttribute("possessor", 0);
    } else if (playerSettling === 2 || playerSettling === 7 || playerTurns === 3){
      icon.style.color = "white";
      this.parentElement.parentElement.setAttribute("possessor", 1);
    } else if (playerSettling === 3 || playerSettling === 6 || playerTurns === 4){
      icon.style.color = "yellow";
      this.parentElement.parentElement.setAttribute("possessor", 2);
    } else if (playerSettling === 4 || playerSettling === 5 || playerTurns === 1){
      icon.style.color = "green";
      this.parentElement.parentElement.setAttribute("possessor", 3);
    };

    icon.style.fontSize = "25px";
    icon.style.position = "absolute";
    icon.style.top = "-10px";
    icon.style.left = "-6px";
    icon.classList.add("fa");
    icon.classList.add("fa-home");
    this.parentElement.style.display = "none";
    this.parentElement.parentElement.appendChild(icon);


};

  });

  li2.addEventListener("click", function(){

// poprwić: rozbudowa cudzych miast!
    if (this.parentElement.parentElement.getAttribute("realEstate") === "village"){
      console.log(this.parentElement.parentElement.getAttribute('possessor') - playerTurns)
      event.stopPropagation();
        if (this.parentElement.parentElement.getAttribute('possessor') - playerTurns == 2 || this.parentElement.parentElement.getAttribute('possessor') - playerTurns == -2){
      this.parentElement.parentElement.setAttribute("realEstate", "town");
    var icon = document.createElement("i");
    if (playerSettling === 1 || playerSettling === 8 || playerTurns === 2){
      icon.style.color = "blue";
    } else if (playerSettling === 2 || playerSettling === 7 || playerTurns === 3){
      icon.style.color = "white";
    } else if (playerSettling === 3 || playerSettling === 6 || playerTurns === 4){
      icon.style.color = "yellow";
    } else if (playerSettling === 4 || playerSettling === 5 || playerTurns === 1){
      icon.style.color = "green";
    };
    icon.style.fontSize = "20px";
    icon.style.position = "absolute";
    icon.style.top = "-8px";
    icon.style.left = "-4px";
    icon.classList.add("fa");
    icon.classList.add("fa-industry");
    this.parentElement.style.display = "none";
    this.parentElement.parentElement.appendChild(icon);
    var previousRealEstate = this.parentElement.parentElement.children
    previousRealEstate[previousRealEstate.length-2].parentNode.removeChild(previousRealEstate[previousRealEstate.length-2]);
  }
  }
  })

  li3.addEventListener("click", function(){
    if (this.parentElement.parentElement.getAttribute("realEstate") === "town"){
      if (this.parentElement.parentElement.getAttribute('possessor') - playerTurns == 2 || this.parentElement.parentElement.getAttribute('possessor') - playerTurns == -2){
          this.parentElement.parentElement.setAttribute("realEstate", "capital");
      event.stopPropagation();
    var icon = document.createElement("i");
    if (playerSettling === 1 || playerSettling === 8 || playerTurns === 2){
      icon.style.color = "blue";
    } else if (playerSettling === 2 || playerSettling === 7 || playerTurns === 3){
      icon.style.color = "white";
    } else if (playerSettling === 3 || playerSettling === 6 || playerTurns === 4){
      icon.style.color = "yellow";
    } else if (playerSettling === 4 || playerSettling === 5 || playerTurns === 1){
      icon.style.color = "green";
    };
    icon.style.fontSize = "20px";
    icon.style.position = "absolute";
    icon.style.top = "-8px";
    icon.style.left = "-4px";
    icon.classList.add("fa");
    icon.classList.add("fa-university");
    this.parentElement.style.display = "none";
    this.parentElement.parentElement.appendChild(icon);
    var previousRealEstate = this.parentElement.parentElement.children;
    previousRealEstate[previousRealEstate.length-2].parentNode.removeChild(previousRealEstate[previousRealEstate.length-2]);
  }
}
  })

  li4.addEventListener("click", function(){
    if (this.parentElement.parentElement.getAttribute("realEstate") === "village" && this.parentElement.parentElement.getAttribute("water") === "true"){
      if (this.parentElement.parentElement.getAttribute('possessor') - playerTurns == 2 || this.parentElement.parentElement.getAttribute('possessor') - playerTurns == -2){
          this.parentElement.parentElement.setAttribute("realEstate", "port village");
      event.stopPropagation();
    var icon = document.createElement("i");
    if (playerSettling === 1 || playerSettling === 8 || playerTurns === 2){
      icon.style.color = "blue";
    } else if (playerSettling === 2 || playerSettling === 7 || playerTurns === 3){
      icon.style.color = "white";
    } else if (playerSettling === 3 || playerSettling === 6 || playerTurns === 4){
      icon.style.color = "yellow";
    } else if (playerSettling === 4 || playerSettling === 5 || playerTurns === 1){
      icon.style.color = "green";
    };
    icon.style.fontSize = "20px";
    icon.style.position = "absolute";
    icon.style.top = "-8px";
    icon.style.left = "-4px";
    icon.classList.add("fa");
    icon.classList.add("fa-simplybuilt");
    this.parentElement.style.display = "none";
    this.parentElement.parentElement.appendChild(icon);
    var previousRealEstate = this.parentElement.parentElement.children;
    previousRealEstate[previousRealEstate.length-2].parentNode.removeChild(previousRealEstate[previousRealEstate.length-2]);
  }
}
  })

  li5.addEventListener("click", function(){
    if (this.parentElement.parentElement.getAttribute("realEstate") === "village"){
      if (this.parentElement.parentElement.getAttribute('possessor') - playerTurns == 2 || this.parentElement.parentElement.getAttribute('possessor') - playerTurns == -2){
          this.parentElement.parentElement.setAttribute("realEstate", "castle");
      event.stopPropagation();
    var icon = document.createElement("i");
    if (playerSettling === 1 || playerSettling === 8 || playerTurns === 2){
      icon.style.color = "blue";
    } else if (playerSettling === 2 || playerSettling === 7 || playerTurns === 3){
      icon.style.color = "white";
    } else if (playerSettling === 3 || playerSettling === 6 || playerTurns === 4){
      icon.style.color = "yellow";
    } else if (playerSettling === 4 || playerSettling === 5 || playerTurns === 1){
      icon.style.color = "green";
    };
    icon.style.fontSize = "25px";
    icon.style.position = "absolute";
    icon.style.top = "-12px";
    icon.style.left = "-6px";
    icon.classList.add("fa");
    icon.classList.add("fa-fort-awesome");
    this.parentElement.style.display = "none";
    this.parentElement.parentElement.appendChild(icon);
    var previousRealEstate = this.parentElement.parentElement.children;
    previousRealEstate[previousRealEstate.length-2].parentNode.removeChild(previousRealEstate[previousRealEstate.length-2]);
  }
}
  })

  li6.addEventListener("click", function(){
    if (this.parentElement.parentElement.getAttribute("realEstate") === "village" || this.parentElement.parentElement.getAttribute("realEstate") === "town" || this.parentElement.parentElement.getAttribute("realEstate") === "capital" || this.parentElement.parentElement.getAttribute("realEstate") === "port village" || this.parentElement.parentElement.getAttribute("realEstate") === "castle"){
          this.parentElement.parentElement.setAttribute("walls", "true");
      event.stopPropagation();

      var siblings = this.parentElement.parentElement.children;
      for (var i = 0; i < siblings.length; i++){
        if(siblings[i].tagName === "I" ){
          console.log("huj")
          var divWalls = document.createElement("div")
          divWalls.style.width = "20px";
          divWalls.style.height = "7px";
          divWalls.style.position = "absolute";
          divWalls.style.left = "-4px";
          divWalls.style.top = "4px";
          divWalls.style.border = "1px dashed black";
          divWalls.style.backgroundColor = "purple";
          this.parentElement.parentElement.appendChild(divWalls);
        }

      }

this.parentElement.style.display = "none"

  }
  })

  li7.addEventListener("click", function(){
    this.parentElement.style.display = "none";
    event.stopPropagation();
  });

newDivField.addEventListener("click", displayMenu);
id++;



if (z%2===0){
    h += 41
  } else {
    h += 82
  }
}


    x = x + 123;

    }
    if (i%2 === 0){
    x = 62;
    y +=  36;
    h = 62;

  } else {
    x = 0;
    y +=36;
    h = 0;
  }


  t += 36;

}

var positionTop = 0;
var positionLeft = 0;

for (var i = 0; i<id; i++){
  var fieldConnection = document.getElementById(i);
  if ((fieldConnection.getAttribute("row")%2 === 0) && (fieldConnection.getAttribute("index") == 0)) {
    var sourceColor1  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")-2) + " no " + (fieldConnection.getAttribute("no")));
    var sourceColor2  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")-1) + " no " + (fieldConnection.getAttribute("no") - 1));
    var sourceColor3  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")) + " no " + (fieldConnection.getAttribute("no")));

    if(sourceColor1 != null) {
    fieldConnection.setAttribute('resource1', sourceColor1.getAttribute("resource"));
    fieldConnection.setAttribute('number1', sourceColor1.getAttribute("number"));
  }

  if(sourceColor2 != null) {
  fieldConnection.setAttribute('resource2', sourceColor2.getAttribute("resource"));
    fieldConnection.setAttribute('number2', sourceColor2.getAttribute("number"));
}

if(sourceColor3 != null) {
fieldConnection.setAttribute('resource3', sourceColor3.getAttribute("resource"));
  fieldConnection.setAttribute('number3', sourceColor3.getAttribute("number"));
}


  } else if ((fieldConnection.getAttribute("row")%2 != 0 && fieldConnection.getAttribute("index") == 0) || (fieldConnection.getAttribute("row")%2 === 0 && fieldConnection.getAttribute("index") == 1)) {
    var sourceColor1  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")-2) + " no " + (fieldConnection.getAttribute("no")));
    var sourceColor2  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")-1) + " no " + (fieldConnection.getAttribute("no")));
    var sourceColor3  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")) + " no " + (fieldConnection.getAttribute("no")));

    if(sourceColor1 != null) {
    fieldConnection.setAttribute('resource1', sourceColor1.getAttribute("resource"));
      fieldConnection.setAttribute('number1', sourceColor1.getAttribute("number"));
  }

  if(sourceColor2 != null) {
  fieldConnection.setAttribute('resource2', sourceColor2.getAttribute("resource"));
    fieldConnection.setAttribute('number2', sourceColor2.getAttribute("number"));
  }

  if(sourceColor3 != null) {
  fieldConnection.setAttribute('resource3', sourceColor3.getAttribute("resource"));
    fieldConnection.setAttribute('number3', sourceColor3.getAttribute("number"));
  }



} else if ((fieldConnection.getAttribute("row")%2 != 0) && (fieldConnection.getAttribute("index") == 1)){
  var sourceColor1  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")-2) + " no " + (fieldConnection.getAttribute("no")));
  var sourceColor2  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")-1) + " no " + (fieldConnection.getAttribute("no") - (-1)));
  var sourceColor3  = document.getElementById("number = row " + (fieldConnection.getAttribute("row")) + " no " + (fieldConnection.getAttribute("no")));

  if(sourceColor1 != null) {
  fieldConnection.setAttribute('resource1', sourceColor1.getAttribute("resource"));
    fieldConnection.setAttribute('number1', sourceColor1.getAttribute("number"));
}

if(sourceColor2 != null) {
fieldConnection.setAttribute('resource2', sourceColor2.getAttribute("resource"));
  fieldConnection.setAttribute('number2', sourceColor2.getAttribute("number"));
}

if(sourceColor3 != null) {
fieldConnection.setAttribute('resource3', sourceColor3.getAttribute("resource"));
  fieldConnection.setAttribute('number3', sourceColor3.getAttribute("number"));
}



}

if ((fieldConnection.getAttribute("resource1") === null || fieldConnection.getAttribute("resource2") === null || fieldConnection.getAttribute("resource3") === null) && (fieldConnection.getAttribute("resource1") != null || fieldConnection.getAttribute("resource2") != null || fieldConnection.getAttribute("resource3") != null)){
  fieldConnection.setAttribute("water", "true");

}


}



var diceNumber1 = 0;
var diceNumber2 = 0;
var dice1Colors = ["black", "black", "black", "yellow", "green", "blue"]

var button = document.getElementById('settle');
var buttonTurn = document.getElementById('endturn');
var paragraphs = document.querySelectorAll("p");
var playerName = document.getElementById('name');
var playerCarriage = document.getElementById('carriage');
var playerResources = document.getElementById('resources');
var playerWood = document.getElementById('wood');
var playerBricks = document.getElementById('bricks');
var playerIron = document.getElementById('iron');
var playerSheeps = document.getElementById('food');
var playerStones = document.getElementById('stones');
var playerWheat = document.getElementById('wheat');
var playerCommodities = document.getElementById('commodity');
var playerLeather = document.getElementById('leather');
var playerCoins = document.getElementById('coins');
var playerPaper = document.getElementById('paper');

var playerSettling = 0;
var playerTurns = 1000;


button.addEventListener("mouseover", function() {
this.style.boxShadow = ("-5px -5px 10px 10px #888")
});

button.addEventListener("mouseout", function() {
this.style.boxShadow = ("")
});

var playerData = document.querySelector("#data");

button.addEventListener("click", function(){
gameStart = true;
button.innerText = "SETTLE"
button.style.paddingTop = "10px";
button.style.height = "50px";
  if (playerSettling === 0){
    playerData.style.color = "blue";
    playerName.innerText = player1.name;
    playerCarriage.innerText = "carriage = " + player1.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player1.wood;
    playerBricks.innerText = "Bricks = " + player1.bricks;
    playerIron.innerText = "Iron = " + player1.iron;
    playerSheeps.innerText = "Food = " + player1.food;
    playerStones.innerText = "Stones = " + player1.stones;
    playerWheat.innerText = "Wheat = " + player1.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player1.leather;
    playerCoins.innerText = "Coins = " + player1.coins;
    playerPaper.innerText = "Paper = " + player1.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerSettling === 1){
    playerData.style.color = "white";
    playerName.innerText = player2.name;
    playerCarriage.innerText = "carriage = " + player2.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player2.wood;
    playerBricks.innerText = "Bricks = " + player2.bricks;
    playerIron.innerText = "Iron = " + player2.iron;
    playerSheeps.innerText = "Food = " + player2.food;
    playerStones.innerText = "Stones = " + player2.stones;
    playerWheat.innerText = "Wheat = " + player2.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player2.leather;
    playerCoins.innerText = "Coins = " + player2.coins;
    playerPaper.innerText = "Paper = " + player2.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerSettling === 2){
    playerData.style.color = "yellow";
    playerName.innerText = player3.name;
    playerCarriage.innerText = "carriage = " + player3.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player3.wood;
    playerBricks.innerText = "Bricks = " + player3.bricks;
    playerIron.innerText = "Iron = " + player3.iron;
    playerSheeps.innerText = "Food = " + player3.food;
    playerStones.innerText = "Stones = " + player3.stones;
    playerWheat.innerText = "Wheat = " + player3.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player3.leather;
    playerCoins.innerText = "Coins = " + player3.coins;
    playerPaper.innerText = "Paper = " + player3.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerSettling === 3){
    playerData.style.color = "green";
    playerName.innerText = player4.name;
    playerCarriage.innerText = "carriage = " + player4.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player4.wood;
    playerBricks.innerText = "Bricks = " + player4.bricks;
    playerIron.innerText = "Iron = " + player4.iron;
    playerSheeps.innerText = "Food = " + player4.food;
    playerStones.innerText = "Stones = " + player4.stones;
    playerWheat.innerText = "Wheat = " + player4.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player4.leather;
    playerCoins.innerText = "Coins = " + player4.coins;
    playerPaper.innerText = "Paper = " + player4.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerSettling === 4){
    playerData.style.color = "green";
    playerName.innerText = player4.name;
    playerCarriage.innerText = "carriage = " + player4.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player4.wood;
    playerBricks.innerText = "Bricks = " + player4.bricks;
    playerIron.innerText = "Iron = " + player4.iron;
    playerSheeps.innerText = "Food = " + player4.food;
    playerStones.innerText = "Stones = " + player4.stones;
    playerWheat.innerText = "Wheat = " + player4.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player4.leather;
    playerCoins.innerText = "Coins = " + player4.coins;
    playerPaper.innerText = "Paper = " + player4.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerSettling === 5){
    playerData.style.color = "yellow";
    playerName.innerText = player3.name;
    playerCarriage.innerText = "carriage = " + player3.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player3.wood;
    playerBricks.innerText = "Bricks = " + player3.bricks;
    playerIron.innerText = "Iron = " + player3.iron;
    playerSheeps.innerText = "Food = " + player3.food;
    playerStones.innerText = "Stones = " + player3.stones;
    playerWheat.innerText = "Wheat = " + player3.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player3.leather;
    playerCoins.innerText = "Coins = " + player3.coins;
    playerPaper.innerText = "Paper = " + player3.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerSettling === 6){
    playerData.style.color = "white";
    playerName.innerText = player2.name;
    playerCarriage.innerText = "carriage = " + player2.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player2.wood;
    playerBricks.innerText = "Bricks = " + player2.bricks;
    playerIron.innerText = "Iron = " + player2.iron;
    playerSheeps.innerText = "Food = " + player2.food;
    playerStones.innerText = "Stones = " + player2.stones;
    playerWheat.innerText = "Wheat = " + player2.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player2.leather;
    playerCoins.innerText = "Coins = " + player2.coins;
    playerPaper.innerText = "Paper = " + player2.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerSettling === 7){
    playerData.style.color = "blue";
    playerName.innerText = player1.name;
    playerCarriage.innerText = "carriage = " + player1.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player1.wood;
    playerBricks.innerText = "Bricks = " + player1.bricks;
    playerIron.innerText = "Iron = " + player1.iron;
    playerSheeps.innerText = "Food = " + player1.food;
    playerStones.innerText = "Stones = " + player1.stones;
    playerWheat.innerText = "Wheat = " + player1.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player1.leather;
    playerCoins.innerText = "Coins = " + player1.coins;
    playerPaper.innerText = "Paper = " + player1.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  }

  if (playerSettling === 8){
    button.style.display = "none";
    for (var i = 0; i < paragraphs.length; i++){
    paragraphs[i].style.display = "none";
  }
    buttonTurn.style.display = "inline-block";
    playerSettling = 10;
    playerTurns = 1;
  } else {
    playerSettling++;
  }

  });

  buttonTurn.addEventListener("mouseover", function() {
  this.style.boxShadow = ("-5px -5px 10px 10px #888")
  });

  buttonTurn.addEventListener("mouseout", function() {
  this.style.boxShadow = ("")
  });

buttonTurn.addEventListener("click", function(){
  buttonTurn.innerText = "END TURN";
  for (var i = 0; i < paragraphs.length; i++){
  paragraphs[i].style.display = "block";
  }
  var dice1 = document.createElement("div");
  var dice2 = document.createElement("div");
  dice1.id = "dice1";
  dice2.id = "dice2";
  body.appendChild(dice1);
  body.appendChild(dice2);

  diceNumber1 = Math.ceil(Math.random() * 6);
  diceNumber2 = Math.ceil(Math.random() * 6);
  dice1Color = dice1Colors[Math.floor(Math.random()*6)];

  totalNumber = diceNumber1 + diceNumber2;
  var connections = document.querySelectorAll(".connections");

//pobieranie surowców

for (var i = 0; i < connections.length; i++){
  if (connections[i].getAttribute("realEstate") === "village"){
     if (connections[i].getAttribute("number1") == totalNumber ){
      var res1String = connections[i].getAttribute("resource1");
      players[connections[i].getAttribute("possessor")][res1String]++;
    }
      if (connections[i].getAttribute("number2") == totalNumber ){
       var res1String = connections[i].getAttribute("resource2");
       players[connections[i].getAttribute("possessor")][res1String]++;
     }
       if (connections[i].getAttribute("number3") == totalNumber ){
        var res1String = connections[i].getAttribute("resource3");
        players[connections[i].getAttribute("possessor")][res1String]++;

     }
  }
}


//dopisać towary handlowe!!
for (var i = 0; i < connections.length; i++){
  if (connections[i].getAttribute("realEstate") === "town"){
     if (connections[i].getAttribute("number1") == totalNumber ){
      var res1String = connections[i].getAttribute("resource1");
      if (res1String == "stones" || res1String == "wheat" || res1String == "bricks"){
      players[connections[i].getAttribute("possessor")][res1String] = players[connections[i].getAttribute("possessor")][res1String] + 2;
    } else if (res1String == "food"){
      players[connections[i].getAttribute("possessor")].food++;
      players[connections[i].getAttribute("possessor")].leather++;
    } else if (res1String == "iron"){
      players[connections[i].getAttribute("possessor")].iron++;
      players[connections[i].getAttribute("possessor")].coins++;
    } else if (res1String == "wood"){
      players[connections[i].getAttribute("possessor")].wood++;
      players[connections[i].getAttribute("possessor")].paper++;
    }
    }
      if (connections[i].getAttribute("number2") == totalNumber ){
       var res1String = connections[i].getAttribute("resource2");
       if (res1String == "stones" || res1String == "wheat" || res1String == "bricks"){
       players[connections[i].getAttribute("possessor")][res1String] = players[connections[i].getAttribute("possessor")][res1String] + 2;
       } else if (res1String == "food"){
         players[connections[i].getAttribute("possessor")].food++;
         players[connections[i].getAttribute("possessor")].leather++;
       } else if (res1String == "iron"){
         players[connections[i].getAttribute("possessor")].iron++;
         players[connections[i].getAttribute("possessor")].coins++;
       } else if (res1String == "wood"){
         players[connections[i].getAttribute("possessor")].wood++;
         players[connections[i].getAttribute("possessor")].paper++;
       }
     }
       if (connections[i].getAttribute("number3") == totalNumber ){
        var res1String = connections[i].getAttribute("resource3");
        if (res1String == "stones" || res1String == "wheat" || res1String == "bricks"){
        players[connections[i].getAttribute("possessor")][res1String] = players[connections[i].getAttribute("possessor")][res1String] + 2;
      } else if (res1String == "food"){
          players[connections[i].getAttribute("possessor")].food++;
          players[connections[i].getAttribute("possessor")].leather++;
        } else if (res1String == "iron"){
          players[connections[i].getAttribute("possessor")].iron++;
          players[connections[i].getAttribute("possessor")].coins++;
        } else if (res1String == "wood"){
          players[connections[i].getAttribute("possessor")].wood++;
          players[connections[i].getAttribute("possessor")].paper++;
        }
     }
  }
}

  if (playerTurns === 1){
    playerData.style.color = "blue";
    playerName.innerText = player1.name;
    playerCarriage.innerText = "carriage = " + player1.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player1.wood;
    playerBricks.innerText = "Bricks = " + player1.bricks;
    playerIron.innerText = "Iron = " + player1.iron;
    playerSheeps.innerText = "Food = " + player1.food;
    playerStones.innerText = "Stones = " + player1.stones;
    playerWheat.innerText = "Wheat = " + player1.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player1.leather;
    playerCoins.innerText = "Coins = " + player1.coins;
    playerPaper.innerText = "Paper = " + player1.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerTurns === 2){
    playerData.style.color = "white";
    playerName.innerText = player2.name;
    playerCarriage.innerText = "carriage = " + player2.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player2.wood;
    playerBricks.innerText = "Bricks = " + player2.bricks;
    playerIron.innerText = "Iron = " + player2.iron;
    playerSheeps.innerText = "Food = " + player2.food;
    playerStones.innerText = "Stones = " + player2.stones;
    playerWheat.innerText = "Wheat = " + player2.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player2.leather;
    playerCoins.innerText = "Coins = " + player2.coins;
    playerPaper.innerText = "Paper = " + player2.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerTurns === 3){
    playerData.style.color = "yellow";
    playerName.innerText = player3.name;
    playerCarriage.innerText = "carriage = " + player3.carriage;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player3.wood;
    playerBricks.innerText = "Bricks = " + player3.bricks;
    playerIron.innerText = "Iron = " + player3.iron;
    playerSheeps.innerText = "Food = " + player3.food;
    playerStones.innerText = "Stones = " + player3.stones;
    playerWheat.innerText = "Wheat = " + player3.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player3.leather;
    playerCoins.innerText = "Coins = " + player3.coins;
    playerPaper.innerText = "Paper = " + player3.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  } else if (playerTurns === 4){
    playerData.style.color = "green";
    playerName.innerText = player4.name;
    playerResources.innerText = "Resources:";
    playerWood.innerText = "Wood = " + player4.wood;
    playerBricks.innerText = "Bricks = " + player4.bricks;
    playerIron.innerText = "Iron = " + player4.iron;
    playerSheeps.innerText = "Food = " + player4.food;
    playerStones.innerText = "Stones = " + player4.stones;
    playerWheat.innerText = "Wheat = " + player4.wheat;
    playerCommodities.innerText = "Commodities:"
    playerLeather.innerText = "leather = " + player4.leather;
    playerCoins.innerText = "Coins = " + player4.coins;
    playerPaper.innerText = "Paper = " + player4.paper;
    body.style.backgroundImage = "-webkit-linear-gradient(" + Math.floor(Math.random()*360) + "deg, white, grey)";
  }

  if (playerTurns === 4){
playerTurns = 1
  } else {
    playerTurns++;
  }




  if (diceNumber1 === 1){
  dice1.style.backgroundColor = dice1Color
  var newPoint = document.createElement("div");
  newPoint.classList.add("pointWhite");
  newPoint.style.margin = "34px";
  dice1.appendChild(newPoint);
} else if (diceNumber1 === 2) {
  dice1.style.backgroundColor = dice1Color
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("pointWhite");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("pointWhite");
    newPoint2.style.bottom = "5px";
    newPoint2.style.right = "5px";
dice1.appendChild(newPoint1);
dice1.appendChild(newPoint2);
} else if (diceNumber1 === 3){
  dice1.style.backgroundColor = dice1Color
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("pointWhite");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("pointWhite");
    newPoint2.style.top = "34px";
    newPoint2.style.left = "34px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("pointWhite");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
dice1.appendChild(newPoint1);
dice1.appendChild(newPoint2);
dice1.appendChild(newPoint3);
} else if (diceNumber1 === 4){
  dice1.style.backgroundColor = dice1Color
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("pointWhite");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("pointWhite");
    newPoint2.style.top = "5px";
    newPoint2.style.right = "5px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("pointWhite");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
    var newPoint4 = document.createElement("div");
      newPoint4.classList.add("pointWhite");
      newPoint4.style.bottom = "5px";
      newPoint4.style.left = "5px";
dice1.appendChild(newPoint1);
dice1.appendChild(newPoint2);
dice1.appendChild(newPoint3);
dice1.appendChild(newPoint4);
} else if (diceNumber1 === 5){
  dice1.style.backgroundColor = dice1Color
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("pointWhite");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("pointWhite");
    newPoint2.style.top = "34px";
    newPoint2.style.left = "34px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("pointWhite");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
    var newPoint4 = document.createElement("div");
      newPoint4.classList.add("pointWhite");
      newPoint4.style.top = "5px";
      newPoint4.style.right = "5px";
    var newPoint5 = document.createElement("div");
      newPoint5.classList.add("pointWhite");
      newPoint5.style.bottom = "5px";
      newPoint5.style.left = "5px";
dice1.appendChild(newPoint1);
dice1.appendChild(newPoint2);
dice1.appendChild(newPoint3);
dice1.appendChild(newPoint4);
dice1.appendChild(newPoint5);
} else if (diceNumber1 === 6){
  dice1.style.backgroundColor = dice1Color
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("pointWhite");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("pointWhite");
    newPoint2.style.top = "5px";
    newPoint2.style.right = "5px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("pointWhite");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
    var newPoint4 = document.createElement("div");
      newPoint4.classList.add("pointWhite");
      newPoint4.style.bottom = "5px";
      newPoint4.style.left = "5px";
    var newPoint5 = document.createElement("div");
      newPoint5.classList.add("pointWhite");
      newPoint5.style.bottom = "34px";
      newPoint5.style.left = "5px";
    var newPoint6 = document.createElement("div");
      newPoint6.classList.add("pointWhite");
      newPoint6.style.bottom = "34px";
      newPoint6.style.right = "5px";
dice1.appendChild(newPoint1);
dice1.appendChild(newPoint2);
dice1.appendChild(newPoint3);
dice1.appendChild(newPoint4);
dice1.appendChild(newPoint5);
dice1.appendChild(newPoint6);
}




  if (diceNumber2 === 1){
  var newPoint = document.createElement("div");
  newPoint.classList.add("point");
  dice2.appendChild(newPoint);
  newPoint.style.margin = "35px";
} else if (diceNumber2 === 2) {
    var newPoint1 = document.createElement("div");
      newPoint1.classList.add("point");
      newPoint1.style.top = "5px";
      newPoint1.style.left = "5px";
    var newPoint2 = document.createElement("div");
    newPoint2.style.bottom = "5px";
      newPoint2.classList.add("point");
      newPoint2.style.right = "5px";
  dice2.appendChild(newPoint1);
  dice2.appendChild(newPoint2);
} else if (diceNumber2 === 3){
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("point");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("point");
    newPoint2.style.top = "36px";
    newPoint2.style.left = "36px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("point");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
dice2.appendChild(newPoint1);
dice2.appendChild(newPoint2);
dice2.appendChild(newPoint3);
} else if (diceNumber2 === 4){
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("point");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("point");
    newPoint2.style.top = "5px";
    newPoint2.style.right = "5px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("point");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
    var newPoint4 = document.createElement("div");
      newPoint4.classList.add("point");
      newPoint4.style.bottom = "5px";
      newPoint4.style.left = "5px";
dice2.appendChild(newPoint1);
dice2.appendChild(newPoint2);
dice2.appendChild(newPoint3);
dice2.appendChild(newPoint4);
} else if (diceNumber2 === 5){
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("point");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("point");
    newPoint2.style.top = "36px";
    newPoint2.style.left = "36px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("point");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
    var newPoint4 = document.createElement("div");
      newPoint4.classList.add("point");
      newPoint4.style.top = "5px";
      newPoint4.style.right = "5px";
    var newPoint5 = document.createElement("div");
      newPoint5.classList.add("point");
      newPoint5.style.bottom = "5px";
      newPoint5.style.left = "5px";
dice2.appendChild(newPoint1);
dice2.appendChild(newPoint2);
dice2.appendChild(newPoint3);
dice2.appendChild(newPoint4);
dice2.appendChild(newPoint5);
} else if (diceNumber2 === 6){
  var newPoint1 = document.createElement("div");
    newPoint1.classList.add("point");
    newPoint1.style.top = "5px";
    newPoint1.style.left = "5px";
  var newPoint2 = document.createElement("div");
    newPoint2.classList.add("point");
    newPoint2.style.top = "5px";
    newPoint2.style.right = "5px";
    var newPoint3 = document.createElement("div");
      newPoint3.classList.add("point");
      newPoint3.style.bottom = "5px";
      newPoint3.style.right = "5px";
    var newPoint4 = document.createElement("div");
      newPoint4.classList.add("point");
      newPoint4.style.bottom = "5px";
      newPoint4.style.left = "5px";
    var newPoint5 = document.createElement("div");
      newPoint5.classList.add("point");
      newPoint5.style.bottom = "36px";
      newPoint5.style.left = "5px";
    var newPoint6 = document.createElement("div");
      newPoint6.classList.add("point");
      newPoint6.style.bottom = "36px";
      newPoint6.style.right = "5px";
dice2.appendChild(newPoint1);
dice2.appendChild(newPoint2);
dice2.appendChild(newPoint3);
dice2.appendChild(newPoint4);
dice2.appendChild(newPoint5);
dice2.appendChild(newPoint6);
}

});

var name1 = prompt("what's your name?");
var name2 = prompt("what's your name?");
var name3 = prompt("what's your name?");
var name4 = prompt("what's your name?");

var Play = function(n){
  this.name = n;
  this.carriage = 1;
  this.wood = 4;
  this.bricks = 4;
  this.wheat = 2;
  this.food = 2;
  this.stones = 0;
  this.leather = 0;
  this.iron = 0;
  this.coins = 0;
  this.paper = 0;
}

var player1 = new Play (name1);
var player2 = new Play (name2);
var player3 = new Play (name3);
var player4 = new Play (name4);

var players = [player1, player2, player3, player4]

var portFields = document.querySelectorAll('[water]');

var portProperty = ["wood", "food", "bricks", "stones", "wheat", "iron", ""]

for (var i = 0; i<portFields.length; i++){
  var randomPorts = Math.floor(Math.random()*8);
  var randomPortsProperty = Math.floor(Math.random()*7);
  if (randomPorts === 0){
    portFields[i].setAttribute("port", "yes");
    portFields[i].setAttribute("portProperty", portProperty[randomPortsProperty]);
    portFields[i].style.border = "3px solid black";
    portFields[i].style.backgroundColor = "red";

  }
}


var ports = document.querySelectorAll('[port]');
var portInfo = document.createElement("div");
body.appendChild(portInfo);
portInfo.style.display = "none";
portInfo.style.position = "absolute"
portInfo.style.width = "350px";
portInfo.style.height = "40px";
portInfo.style.top = "0px";
portInfo.style.left = "5px";
portInfo.style.border = "5px solid black";
portInfo.style.fontSize = "25px";

for (var i = 0; i < ports.length; i++){
  ports[i].addEventListener("mouseover", function(){
  portInfo.style.display = "inline-block";
  if (this.getAttribute("portProperty") != ""){
  portInfo.innerText = this.getAttribute("portProperty") + " exchange 2:1";
} else {
  portInfo.innerText = "exchange all resources 3:1"
}
  });

ports[i].addEventListener("mouseout", function(){
  portInfo.style.display = "none";
});
}

})
